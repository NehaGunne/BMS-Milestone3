import React, { useEffect, useState } from 'react';
import AddBook from './add-book-page';
import './App.css';
import Home from './homePage'
import Login from './login-page';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import Navbar from './navbar';
import Description from './description'; 
import SignUp from './signup';
import ProtectedRoute from './protected-route';
function App() {
  const [isAuth,setAuthorization]=useState(false)  
  //let [token,setToken]=useState(null)
  console.log(isAuth);
  //console.log(token);
  
 /* async function loggedIn(){
    console.log('i am here')
    await setAuth('false')
    console.log(isAuth)
  }
  const loggedOut=()=>{
    setAuth('false')
  }*/
  let val:any=document.cookie
  console.log(val);
  
  useEffect(()=>{
    if(val){
      setAuthorization(true)
      
    }else{
      setAuthorization(false)
    }
    console.log('routes',isAuth);

  }) 
  return (
    <Router>
      <Navbar isAuth={isAuth}/>
        <div>
          <Switch>
            <Route path='/' exact component={Home}/>
            <Route path='/book/:id' >
              <Description isAuth={isAuth}/>
            </Route>
            <ProtectedRoute path='/add-book' component={AddBook}/>
            <Route path='/login'>
              <Login/>
            </Route>
            <Route path='/signup'>
              <SignUp/>
            </Route>
          </Switch>
        </div>

    </Router>
  )
}

export default App;
