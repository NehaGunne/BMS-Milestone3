import React from 'react';
import { useHistory } from 'react-router';
 interface props{
    isAuth:boolean,
    //setAuth:Function
} 
const Navbar=(props:props)=>{
    console.log('nav',props.isAuth);
    
    const history=useHistory();
    async function logOut() {
        try{
            let res=await fetch('http://localhost:8000/users/logout',{
                credentials:'include'
            });
            console.log(res);
            //props.setAuth(false)
            history.push('/')
            window.location.reload();

        }catch(err){
            console.log(err);
            
        }
        
    }
    
    return(
        <nav className="navbar navbar-expand-lg navbar-light nav-bg">
            <a className="navbar-brand nav-text" href="#">Book Management System</a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div className="navbar-nav ml-auto">
                <a className="nav-item nav-text nav-link active" href="http://localhost:3000/"
                >Home <span className="sr-only">(current)</span></a>
                <a className="nav-item nav-link nav-text"
                 href="http://localhost:3000/add-book">Add Books</a>
               {!props.isAuth && <a className="nav-item nav-link nav-text" 
                href="http://localhost:3000/login">Login</a>}
               {!props.isAuth && <a className="nav-item nav-link nav-text"
                 href="http://localhost:3000/signup">Signup</a>}
                {props.isAuth && <a className="nav-item nav-link nav-text" href='#'
                 onClick={logOut}>log out</a>}
                </div>
            </div>
        </nav>
    )
}
export default Navbar;